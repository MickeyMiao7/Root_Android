bash /system/bin/mydaemon
bash /system/bin/mysu
